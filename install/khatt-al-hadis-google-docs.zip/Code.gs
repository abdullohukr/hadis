/**
 * Hadislar for Google Docs (editor add-on).
 * The sidebar is the website https://hadis.abdulloh.org/ in a frame (?host=gdocs). Its "Insert" button sends
 * the paragraphs with every run's font, size and style already resolved (see hostDoc in web/app.js);
 * insertHadith() builds them in the document, after the paragraph with the cursor.
 */

function onOpen(e) {
  DocumentApp.getUi().createAddonMenu()
    .addItem('Ҳадислар', 'showSidebar')
    .addToUi();
}

function onInstall(e) {
  onOpen(e);
}

function showSidebar() {
  var html = HtmlService.createHtmlOutputFromFile('Sidebar').setTitle('Ҳадислар');
  DocumentApp.getUi().showSidebar(html);
}

var ALIGN = {
  both: DocumentApp.HorizontalAlignment.JUSTIFY,
  center: DocumentApp.HorizontalAlignment.CENTER,
  left: DocumentApp.HorizontalAlignment.LEFT,
  right: DocumentApp.HorizontalAlignment.RIGHT
};

/** payload = {doc: [{dir, kind, align, line, runs: [{t, font, size, b, i, u, color}]}]} */
function insertHadith(payload) {
  var paras = (payload && payload.doc) || [];
  if (!paras.length) return { ok: false };
  var doc = DocumentApp.getActiveDocument(), body = doc.getBody();
  var container = body, index = body.getNumChildren(), reuse = null;

  // the paragraph with the cursor (or the start of the selection): the hadith goes after it; an empty one is used
  var cursor = doc.getCursor(), selection = doc.getSelection(), el = null;
  if (cursor) el = cursor.getElement();
  else if (selection && selection.getRangeElements().length) el = selection.getRangeElements()[0].getElement();
  while (el && el.getType() !== DocumentApp.ElementType.PARAGRAPH && el.getType() !== DocumentApp.ElementType.LIST_ITEM) {
    el = el.getParent();
  }
  if (el) {
    container = el.getParent();
    index = container.getChildIndex(el) + 1;
    if (el.getType() === DocumentApp.ElementType.PARAGRAPH && !el.getText().trim()) { reuse = el; index -= 1; }
  }

  var last = null, inserted = [];
  paras.forEach(function (p, n) {
    var par = n === 0 && reuse ? reuse : container.insertParagraph(index + n, '');
    inserted.push(par);
    if (par === reuse) par.clear();
    par.setHeading(DocumentApp.ParagraphHeading.NORMAL);
    var rtl = p.dir === 'rtl';
    par.setLeftToRight(!rtl);
    // as in Word, left / right are taken as the start / end of the line, so they are swapped in right-to-left text
    var align = p.align || 'both';
    if (rtl && (align === 'left' || align === 'right')) align = align === 'left' ? 'right' : 'left';
    par.setAlignment(ALIGN[align] || ALIGN.both);
    if (p.line) par.setLineSpacing(p.line);

    var runs = (p.runs || []).filter(function (r) { return r.t; });
    var all = runs.map(function (r) { return r.t; }).join('');
    if (!all) return;
    var text = par.appendText(all), at = 0;
    runs.forEach(function (r) {
      var a = at, b = at + r.t.length - 1;
      at += r.t.length;
      if (r.font) text.setFontFamily(a, b, r.font);
      if (r.size) text.setFontSize(a, b, r.size);
      text.setBold(a, b, !!r.b);
      text.setItalic(a, b, !!r.i);
      text.setUnderline(a, b, !!r.u);
      if (r.color) text.setForegroundColor(a, b, r.color);
    });
    last = text;
  });
  if (last) doc.setCursor(doc.newPosition(last, last.getText().length));
  rememberInserted(doc, inserted);
  return { ok: true };
}

/* "Undo": the paragraphs of the last insert are remembered in a named range whose name carries a hash of their text, so
   they are taken out only if they are still exactly as inserted. Never allowed to break the insert itself. */
var LAST_PREFIX = 'khatt-last-';
function hashOf_(pars) {
  var s = pars.map(function (p) { return p.getText(); }).join('\n'), h = 5381;
  for (var i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0;
  return h.toString(36) + '-' + pars.length;
}
function lastRanges_(doc) {
  return doc.getNamedRanges().filter(function (r) { return r.getName().indexOf(LAST_PREFIX) === 0; });
}
function rememberInserted(doc, pars) {
  try {
    lastRanges_(doc).forEach(function (r) { r.remove(); });
    var rb = doc.newRange();
    pars.forEach(function (p) { rb.addElement(p); });
    doc.addNamedRange(LAST_PREFIX + hashOf_(pars), rb.build());
  } catch (e) { /* no undo, the insert stays */ }
}
/** answers {ok, error: 'gone' | 'changed' | 'none'} */
function undoLastHadith() {
  var doc = DocumentApp.getActiveDocument(), found = lastRanges_(doc);
  if (!found.length) return { ok: false, error: 'none' };
  var nr = found[0], pars = nr.getRange().getRangeElements().map(function (e) { return e.getElement(); })
    .filter(function (e) { return e.getType() === DocumentApp.ElementType.PARAGRAPH; }).map(function (e) { return e.asParagraph(); });
  if (!pars.length) { nr.remove(); return { ok: false, error: 'gone' }; }
  if (LAST_PREFIX + hashOf_(pars) !== nr.getName()) return { ok: false, error: 'changed' };
  pars.forEach(function (p) {
    try { p.removeFromParent(); } catch (e) { p.clear(); }      // the last paragraph of a document cannot be removed: it is emptied
  });
  nr.remove();
  return { ok: true };
}


/** the selected text of the document (live search): '' when nothing is selected; at most 400 characters */
function getSelectedText() {
  var sel = DocumentApp.getActiveDocument().getSelection();
  if (!sel) return '';
  var out = [];
  sel.getRangeElements().forEach(function (re) {
    var el = re.getElement();
    if (el.editAsText) {
      var t = el.asText().getText();
      out.push(re.isPartial() ? t.substring(re.getStartOffset(), re.getEndOffsetInclusive() + 1) : t);
    }
  });
  return out.join(' ').slice(0, 400);
}

/* The alphabet of the panel (cyrl | latn | new) and its apostrophes (mod | typo | ascii), for this user: the frame of
   the sidebar may lose the localStorage of the site, the panel asks for it on load (Sidebar.html) */
var PREF_KEY = 'hadis-pref';
function getPref() {
  try { return JSON.parse(PropertiesService.getUserProperties().getProperty(PREF_KEY) || '{}'); } catch (e) { return {}; }
}
function savePref(p) {
  var o = {
    script: /^(cyrl|latn|new)$/.test(p && p.script || '') ? p.script : '',
    apos: /^(mod|typo|ascii)$/.test(p && p.apos || '') ? p.apos : ''
  };
  // «Кун ҳадиси»: on / off, hidden for a date, the time of the choice (the newest copy wins in the panel)
  if (p && typeof p.day === 'boolean' && +p.dayAt > 0) {
    o.day = p.day; o.dayHide = /^\d{4}-\d{1,2}-\d{1,2}$/.test(p.dayHide || '') ? p.dayHide : ''; o.dayAt = +p.dayAt;
  } else {
    var old = getPref();
    if (old && typeof old.day === 'boolean') { o.day = old.day; o.dayHide = old.dayHide || ''; o.dayAt = +old.dayAt || 0; }
  }
  PropertiesService.getUserProperties().setProperty(PREF_KEY, JSON.stringify(o));
  return true;
}
