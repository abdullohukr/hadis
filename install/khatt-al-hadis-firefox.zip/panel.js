/* The panel is the website in a frame. Messages with the website (only from / to its own origin):
     site -> panel  khatt-insert {html, text, mode, picHtml, restHtml, pic}: put it into the field that has the focus
                    in the current tab (see khattInsertHere in insert.js); the answer is khatt-result {ok, ask, pic}.
                    Where that is not possible (no field, Google Docs, a page the extension may not touch) ok is false
                    and the website tells to paste: it already copied.
                    khatt-ready: the website is ready for messages; khatt-pref {extInsert, script, apos, day, dayHide, dayAt}:
                    its choice changed (day: «Кун ҳадиси» on/off, dayHide: hidden for that date, dayAt: the time of it).
     panel -> site  khatt-search {q}: search this (context menu, shortcut); khatt-pref {…}: the saved one.
   The choice of the way to insert into editors (extInsert) is kept in storage.sync, so it is not lost with the site's data. */
var api = typeof browser !== 'undefined' ? browser : chrome;
// as an origin (e.origin is always in lower case: an address written with capitals would never match)
var SITE = new URL('https://hadis.abdulloh.org').origin, frame = document.getElementById('app');
var area = api.storage.session || api.storage.local, ready = false;

function post(msg) { if (frame.contentWindow) frame.contentWindow.postMessage(msg, SITE); }
function reply(r, error) {
  post({ type: 'khatt-result', ok: r === true || r === 'nopic', ask: r === 'ask', pic: r === 'nopic' ? 'none' : '', error: error || '' });
}

/* a search asked for by the context menu or the shortcut (the newest one, if it is not old) */
function takeSearch() {
  if (!ready) return;
  area.get('khattSearch').then(function (s) {
    var x = s && s.khattSearch;
    if (!x || !x.q) return;
    area.remove('khattSearch');
    if (Date.now() - (x.t || 0) < 120000) post({ type: 'khatt-search', q: x.q });
  }).catch(function () {});
}
api.storage.onChanged.addListener(function (ch) { if (ch.khattSearch && ch.khattSearch.newValue) takeSearch(); });

var liveTimer = null, liveLast = '', liveBusy = false;
function liveTick() {
  if (document.hidden || liveBusy) return;
  liveBusy = true;
  api.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    var tab = tabs[0]; if (!tab) return;
    return khattRun(api, tab.id, khattSelectedText).then(function (txt) {
      if (txt && /[\u0600-\u06FF]/.test(txt) && txt !== liveLast) { liveLast = txt; post({ type: 'khatt-search', q: String(txt).slice(0, 400), live: true }); }
    });
  }).catch(function () {}).then(function () { liveBusy = false; });
}

window.addEventListener('message', function (e) {
  var d = e.data;
  if (e.origin !== SITE || e.source !== frame.contentWindow || !d) return;
  if (d.type === 'khatt-ready') {
    ready = true;
    api.storage.sync.get(['extInsert', 'script', 'apos', 'dayPref']).then(function (s) {
      var dp = s && s.dayPref && typeof s.dayPref === 'object' ? s.dayPref : null;
      post({ type: 'khatt-pref', extInsert: (s && s.extInsert) || '', script: (s && s.script) || '', apos: (s && s.apos) || '',
             day: dp ? !!dp.day : undefined, dayHide: dp ? String(dp.dayHide || '') : undefined, dayAt: dp ? +dp.dayAt || 0 : 0 });
    }, function () {});
    takeSearch();
    return;
  }
  if (d.type === 'khatt-pref') {
    if (/^(ask|text|picture)$/.test(d.extInsert || '')) api.storage.sync.set({ extInsert: d.extInsert }).catch(function () {});
    var keep = {};                                     // the alphabet of the panel (cyrl | latn | new) and its apostrophes
    if (/^(cyrl|latn|new)$/.test(d.script || '')) keep.script = d.script;
    if (/^(mod|typo|ascii)$/.test(d.apos || '')) keep.apos = d.apos;
    // «Кун ҳадиси» turned off / hidden for a day: kept here too, the site's frame may lose its storage
    if (typeof d.day === 'boolean' && +d.dayAt > 0) keep.dayPref = { day: d.day, dayHide: /^\d{4}-\d{1,2}-\d{1,2}$/.test(d.dayHide || '') ? d.dayHide : '', dayAt: +d.dayAt };
    if (keep.script || keep.apos || keep.dayPref) api.storage.sync.set(keep).catch(function () {});
    return;
  }
  if (d.type === 'khatt-selection-now') {              // the key Alt+F in the panel: search the selected text of the page once
    api.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
      return tabs[0] && khattRun(api, tabs[0].id, khattSelectedText);
    }).then(function (txt) { post(txt ? { type: 'khatt-search', q: String(txt).slice(0, 500) } : { type: 'khatt-search', q: '' }); }).catch(function () {});
    return;
  }
  if (d.type === 'khatt-live') {                       // live search: the selected Arabic text of the page, every 1.5 s while it is on
    clearInterval(liveTimer); liveLast = '';
    if (d.on) liveTimer = setInterval(liveTick, 500);
    return;
  }
  if (d.type !== 'khatt-insert') return;
  var job = { html: String(d.html || ''), text: String(d.text || ''), mode: /^(ask|text|picture)$/.test(d.mode || '') ? d.mode : 'text',
              picHtml: d.picHtml ? String(d.picHtml) : '', restHtml: d.restHtml ? String(d.restHtml) : '', pic: d.pic ? String(d.pic) : '' };
  api.tabs.query({ active: true, currentWindow: true }).then(function (tabs) {
    var tab = tabs[0];
    if (!tab) return reply(false);
    return khattRun(api, tab.id, khattInsertHere, function (all) { return [job, !all]; }).then(function (r) {
      // "Insert the last hadith again" (context menu): in an editor the way chosen now, never a question
      if (r === true || r === 'nopic') api.storage.local.set({ khattLast: Object.assign({}, job, { mode: job.mode === 'ask' ? 'text' : job.mode }) }).catch(function () {});
      reply(r);
    });
  }).catch(function () { reply(false); });
});
