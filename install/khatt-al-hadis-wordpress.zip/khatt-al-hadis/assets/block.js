/* Block "Hadith": no build step, the editor's own React (wp.element). The saved markup is the HTML from the
   website inside <div class="khatt-hadith">, so the post shows it without the plugin too (only the font is lost). */
(function (wp) {
  'use strict';
  var el = wp.element.createElement, RawHTML = wp.element.RawHTML, __ = wp.i18n.__;
  var be = wp.blockEditor, cmp = wp.components, K = window.KhattAlHadis;
  var useBlockProps = be.useBlockProps || function (p) { return p || {}; };
  var icon = el('svg', { viewBox: '0 0 24 24', width: 24, height: 24 },
    el('path', { d: 'M4 5.5C4 4.7 4.7 4 5.5 4H11v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Zm9-1.5h5.5c.8 0 1.5.7 1.5 1.5v13c0 .8-.7 1.5-1.5 1.5H13V4Z', fill: 'currentColor' }));

  wp.blocks.registerBlockType('khatt/hadith', {
    apiVersion: 3,
    title: __('Ҳадис', 'khatt-al-hadis'),
    description: __('«Ҳадислар»дан арабча матн, таржима ва тахриж.', 'khatt-al-hadis'),
    category: 'text',
    icon: icon,
    keywords: ['ҳадис', 'hadis', 'тахриж', 'taxrij', 'حديث'],
    supports: { html: false, align: ['wide', 'full'] },
    attributes: { html: { type: 'string', source: 'html', selector: '.khatt-hadith' } },

    edit: function (props) {
      var html = props.attributes.html;
      function choose() { K.pick(function (h) { props.setAttributes({ html: h }); }); }
      var bp = useBlockProps();
      if (!html) {
        return el('div', bp, el(cmp.Placeholder, {
          icon: icon, label: __('Ҳадис', 'khatt-al-hadis'),
          instructions: __('Ҳадисни топинг, таржима ва тахрижни танланг, «Қўйиш»ни босинг.', 'khatt-al-hadis')
        }, el(cmp.Button, { variant: 'primary', isPrimary: true, onClick: choose }, __('Ҳадис танлаш', 'khatt-al-hadis'))));
      }
      return el('div', bp,
        el(be.BlockControls, null, el(cmp.ToolbarGroup, null,
          el(cmp.ToolbarButton, { icon: 'edit', label: __('Бошқа ҳадис танлаш', 'khatt-al-hadis'), onClick: choose }))),
        el('div', { className: 'khatt-hadith' }, el(RawHTML, null, html)));
    },

    save: function (props) {
      var bp = be.useBlockProps && be.useBlockProps.save ? be.useBlockProps.save() : {};
      return el('div', bp, el('div', { className: 'khatt-hadith' }, el(RawHTML, null, props.attributes.html)));
    }
  });
})(window.wp);
