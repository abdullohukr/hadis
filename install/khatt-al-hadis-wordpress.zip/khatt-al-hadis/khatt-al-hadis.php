<?php
/**
 * Plugin Name:       Ҳадислар
 * Plugin URI:        https://hadis.abdulloh.org/
 * Description:       Ҳадисларни топинг ва ёзув ҳамда саҳифаларга қўйинг: арабча матн, ўзбекча таржима ва тахриж (манба, рақам, даража). Таҳрирлагичдаги ён панель (Word’даги каби) ҳадисни оддий матн сифатида қўяди; классик таҳрирлагичда «Ҳадис» тугмаси бор.
 * Version:           0.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.0
 * Author:            Abdulloh Hamidulloh al-Madiyniy
 * Author URI:        https://hadis.abdulloh.org/
 * License:           GPL-2.0-or-later
 * Text Domain:       khatt-al-hadis
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KHATT_VERSION', '0.1.0' );
define( 'KHATT_SITE', 'https://hadis.abdulloh.org' );

/* The picker: the website in a dialog (?host=wp); its "Insert" button sends ready HTML (see sendToHost in web/app.js). */
function khatt_register() {
	$url  = plugin_dir_url( __FILE__ );
	$site = untrailingslashit( apply_filters( 'khatt_site', KHATT_SITE ) ); // a filter only for testing against a local copy of the site
	wp_register_style( 'khatt-al-hadis', $url . 'assets/style.css', array(), KHATT_VERSION );
	wp_register_script( 'khatt-picker', $url . 'assets/picker.js', array(), KHATT_VERSION, true );
	wp_localize_script( 'khatt-picker', 'KhattAlHadis', array(
		'site'  => $site,
		'origin' => preg_replace( '#^(https?://[^/]+).*$#', '$1', $site ),
		'url'   => $site . '/index.html?host=wp',
		'title' => __( 'Ҳадис', 'khatt-al-hadis' ),
		'close' => __( 'Ёпиш', 'khatt-al-hadis' ),
	) );
	wp_register_script( 'khatt-block', $url . 'assets/block.js',
		array( 'khatt-picker', 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ), KHATT_VERSION, true );
	wp_register_script( 'khatt-sidebar', $url . 'assets/sidebar.js',
		array( 'khatt-picker', 'wp-plugins', 'wp-rich-text', 'wp-edit-post', 'wp-editor', 'wp-element', 'wp-data', 'wp-blocks', 'wp-dom-ready', 'wp-i18n' ), KHATT_VERSION, true );
	register_block_type( 'khatt/hadith', array(
		'editor_script' => 'khatt-block',
		'style'         => 'khatt-al-hadis',
	) );
}
add_action( 'init', 'khatt_register' );

/* Block editor: the side panel (the website in a frame; the hadith goes into the post as ordinary paragraphs) */
function khatt_editor_assets() {
	wp_enqueue_script( 'khatt-sidebar' );
}
add_action( 'enqueue_block_editor_assets', 'khatt_editor_assets' );

/* The styles of the hadith paragraphs: in the editor and on the site (only on posts that contain an hadith) */
function khatt_block_assets() {
	if ( is_admin() ) {
		wp_enqueue_style( 'khatt-al-hadis' );
	}
}
add_action( 'enqueue_block_assets', 'khatt_block_assets' );

/* Classic editor: an "Hadith" button next to "Add Media" */
function khatt_media_button() {
	wp_enqueue_script( 'khatt-picker' );
	wp_enqueue_style( 'khatt-al-hadis' );
	echo '<button type="button" class="button khatt-classic-button">'
		. '<span class="khatt-classic-icon" aria-hidden="true">&#x275D;</span> ' . esc_html__( 'Ҳадис', 'khatt-al-hadis' ) . '</button>';
}
add_action( 'media_buttons', 'khatt_media_button', 20 );

/* The Arabic font on the site, for hadiths inserted with the classic editor too */
function khatt_front_style() {
	if ( ! is_singular() ) {
		return;
	}
	$content = (string) get_post_field( 'post_content', get_queried_object_id() );
	if ( false !== strpos( $content, 'khatt-hadith' ) ) {
		wp_enqueue_style( 'khatt-al-hadis' );
	}
}
add_action( 'wp_enqueue_scripts', 'khatt_front_style' );
